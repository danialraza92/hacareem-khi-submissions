package com.example.ayaz.predictionapp;

import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by aali on 4/15/2017.
 */

public class WebService {
    public JSONObject loginReqResponse;
    public String checkInReqResponse;
    public String conversionReqResponse;
    public int responseId;
    public String logoutResponse;
    public String conversionSimpleReqResponse;
    public JSONObject jsonObject;
    public String checkoutResponse;

    public JSONObject Login(final String userId, final String time, final String lat, final String longi, RequestQueue requestQueue) {

        try {

            StringRequest postRequest = new StringRequest(Request.Method.GET, "http://192.168.8.104:3080/bookingDropoff?user_id="+userId+"&pickup_time="+time+"&pickup_lat="+lat+"&pickup_long="+longi,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d("Response", response);
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                if (jsonObject.has("dropoffLocations"))
                                    loginReqResponse = jsonObject;
                                else
                                    loginReqResponse = jsonObject.put("Error", "Error");

                                Log.d("Response", loginReqResponse.toString());
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Log.d("Error.Response", "---" + error.getMessage());
                            try {
                                jsonObject = new JSONObject();
                                loginReqResponse = jsonObject.put("Error", "Error");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    Log.d("Hellooooo---------",""+userId+"--"+time+"---"+lat+"---"+longi);
//                    params.put("user_id", userId);
//                    params.put("pickup_time", time);
//                    params.put("pickup_lat", lat);
//                    params.put("pickup_long", longi);

                    return params;
                }
            };


            requestQueue.add(postRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }


        Log.d("Resp", "----" + loginReqResponse);
        return loginReqResponse;
    }

    public JSONObject getLoginReqResponse() {

        return loginReqResponse;
    }

    public String CheckIn(final String uId, final String xCoordinate, final String yCoordinate, RequestQueue requestQueue) {

        try {


            StringRequest postRequest = new StringRequest(Request.Method.POST, ConfigAPI.checkInURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d("Response", response.toString());
                            checkInReqResponse = response.toString();

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Log.d("Error.Response", "---" + error.getMessage());
                            checkInReqResponse = "Error";
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("userid", uId);
                    params.put("xcoordinate", xCoordinate);
                    params.put("ycoordinate", yCoordinate);

                    return params;
                }
            };


            requestQueue.add(postRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return checkInReqResponse;
    }

    public String getCheckInReqResponse() {

        return checkInReqResponse;
    }


    public String CheckOutUrl(final String uId, final String xCoordinate, final String yCoordinate, RequestQueue requestQueue) {

        try {


            StringRequest postRequest = new StringRequest(Request.Method.POST, ConfigAPI.checkoutURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d("Response", response.toString());
                            checkoutResponse = response.toString();

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Log.d("Error.Response", "---" + error.getMessage());
                            checkoutResponse = "Error";
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("userid", uId);
                    params.put("xcoordinate", xCoordinate);
                    params.put("ycoordinate", yCoordinate);

                    return params;
                }
            };


            requestQueue.add(postRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return checkoutResponse;
    }

    public String getCheckoutResponse() {

        return checkoutResponse;
    }

    public String Logout(final String uId, final String time, RequestQueue requestQueue) {


        try {

            StringRequest postRequest = new StringRequest(Request.Method.POST, ConfigAPI.logoutURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d("Response", response);
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = new JSONObject(response);
                                if (jsonObject.has("status"))
                                    logoutResponse = jsonObject.get("status").toString();
                                else
                                    logoutResponse = "Error";

                                Log.d("Response", logoutResponse);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Log.d("Error.Response", "---" + error.getMessage());
                            logoutResponse = "Error";
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("userid", uId);
                    params.put("time", time);
                    return params;
                }
            };


            requestQueue.add(postRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return logoutResponse;
    }

    public String getLogoutResponse() {

        return logoutResponse;
    }

    public String Conversion(final String uId, final String city, final String store, final String name, final String phone, final String range, final String time, final String month, final String year, final String conversion, final String lattitude, final String longitude, RequestQueue requestQueue) {

        try {

            StringRequest postRequest = new StringRequest(Request.Method.POST, ConfigAPI.customerURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d("Response", response);
                            conversionSimpleReqResponse = response;
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            error.printStackTrace();
                            conversionSimpleReqResponse = "Error";
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("userid", uId);
                    params.put("customername", name);
                    params.put("city", city);
                    params.put("store", store);
                    params.put("phone", phone);
                    params.put("month", month);
                    params.put("year", year);
                    params.put("range", range);
                    params.put("xcoordinate", lattitude);
                    params.put("ycoordinate", longitude);
                    params.put("time", time);
                    params.put("conversion", conversion);
                    return params;
                }
            };


            requestQueue.add(postRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return conversionSimpleReqResponse;
    }

    public String getConversionSimpleReqResponse() {

        return conversionSimpleReqResponse;
    }

    public void Conversion(int id, final String uId, final String city, final String store, final String name, final String phone, final String range, final String time, final String month, final String year, final String conversion, final String lattitude, final String longitude, RequestQueue requestQueue) {

        try {
            Log.d("Id", "----" + id);
            responseId = id;
            Log.d("responseId1", "----" + id);
            StringRequest postRequest = new StringRequest(Request.Method.POST, ConfigAPI.customerURL,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // response
                            Log.d("Response----", response);
                            conversionReqResponse = response;
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Log.d("Error.Response", "---" + error.getMessage());
                            conversionReqResponse = "Error";
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("userid", uId);
                    params.put("customername", name);
                    params.put("city", city);
                    params.put("store", store);
                    params.put("phone", phone);
                    params.put("month", month);
                    params.put("year", year);
                    params.put("range", range);
                    params.put("xcoordinate", lattitude);
                    params.put("ycoordinate", longitude);
                    params.put("time", time);
                    params.put("conversion", conversion);
                    return params;
                }
            };


            requestQueue.add(postRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public String getConversionReqResponse() {

        Log.d("responseId2", "----" + responseId + "------" + conversionReqResponse);

        return responseId + "," + conversionReqResponse;
    }
}
