package com.example.ayaz.predictionapp.Fragments;

/**
 * Created by Ravi on 29/07/15.
 */

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.ayaz.predictionapp.GeoHashUtils;
import com.example.ayaz.predictionapp.Modules.DirectionFinder;
import com.example.ayaz.predictionapp.Modules.DirectionFinderListener;
import com.example.ayaz.predictionapp.Modules.GPSTracker;
import com.example.ayaz.predictionapp.Modules.Route;

import com.example.ayaz.predictionapp.R;
import com.example.ayaz.predictionapp.WebService;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class HomeFragment extends Fragment implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, DirectionFinderListener, ResultCallback {

    Location mLastLocation;
    double lat = 0, lng = 0;
    protected GoogleApiClient mGoogleApiClient;
    WebService webService;
    protected LocationRequest locationRequest;
    private GoogleMap mMap;
    private Button btnFindPath;
    private EditText etOrigin;
    private EditText etDestination;
    private List<Marker> originMarkers = new ArrayList<>();
    private List<Marker> destinationMarkers = new ArrayList<>();
    private List<Polyline> polylinePaths = new ArrayList<>();
    private ProgressDialog progressDialog;

    TextView tvDuration, tvDistance;
    GPSTracker gpsTracker;
    Context thiscontext;
    LocationManager lm;
    RelativeLayout relativeLayout;
    Geocoder geo;
    Location location;
    double longitude, latitude;
    private SupportMapFragment mapFragment;
    FragmentManager fm;
    String address;
    int REQUEST_CHECK_SETTINGS = 100;
    LocationManager locationManager;

    public HomeFragment() {
        // Required empty public constructor
    }

    private void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

//    @Override
//    public void onStart() {
//        super.onStart();
//
////        mGoogleApiClient.connect();
//    }

    @Override
    public void onDirectionFinderStart() {
        progressDialog = ProgressDialog.show(getActivity(), "Please wait.",
                "Finding direction..!", true);

        if (originMarkers != null) {
            for (Marker marker : originMarkers) {
                marker.remove();
            }
        }

        if (destinationMarkers != null) {
            for (Marker marker : destinationMarkers) {
                marker.remove();
            }
        }

        if (polylinePaths != null) {
            for (Polyline polyline : polylinePaths) {
                polyline.remove();
            }
        }
    }

    @Override
    public void onConnected(Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onDirectionFinderSuccess(List<Route> routes) {
        progressDialog.dismiss();
        polylinePaths = new ArrayList<>();
        originMarkers = new ArrayList<>();
        destinationMarkers = new ArrayList<>();

        for (Route route : routes) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(route.startLocation, 16));
            tvDuration.setText(route.duration.text);
            tvDistance.setText(route.distance.text);

            originMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.start_blue))
                    .title(route.startAddress)
                    .position(route.startLocation)));
            destinationMarkers.add(mMap.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.end_green))
                    .title(route.endAddress)
                    .position(route.endLocation)));

            PolylineOptions polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(Color.RED).
                    width(10);

            for (int i = 0; i < route.points.size(); i++)
                polylineOptions.add(route.points.get(i));

            polylinePaths.add(mMap.addPolyline(polylineOptions));
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        thiscontext = inflater.getContext();
        FragmentManager fm = getChildFragmentManager();
        mapFragment = (SupportMapFragment) fm.findFragmentById(R.id.map);
        if (mapFragment == null) {
            mapFragment = SupportMapFragment.newInstance();
            fm.beginTransaction().replace(R.id.map, mapFragment).commit();
        }
        locationManager = (LocationManager) getActivity()
                .getSystemService(getActivity().LOCATION_SERVICE);

        mapFragment.getMapAsync(this);
        btnFindPath = (Button) rootView.findViewById(R.id.btnFindPath);
        relativeLayout = (RelativeLayout)rootView.findViewById(R.id.relativeLayout);

//        etOrigin = (EditText) rootView.findViewById(R.id.etOrigin);
//        etDestination = (EditText) rootView.findViewById(R.id.etDestination);
//        etDestination.bringToFront();
//        etOrigin.bringToFront();
        tvDuration = (TextView) rootView.findViewById(R.id.tvDuration);
        tvDistance = (TextView) rootView.findViewById(R.id.tvDistance);
        tvDistance.bringToFront();
        tvDuration.bringToFront();
        btnFindPath.bringToFront();
        btnFindPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRequest();
            }
        });

//        mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
//                .addApi(LocationServices.API)
//                .addConnectionCallbacks(this)
//                .addOnConnectionFailedListener(this).build();
//        mGoogleApiClient.connect();

//        locationRequest = LocationRequest.create();
//        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//        locationRequest.setInterval(30 * 1000);
//        locationRequest.setFastestInterval(5 * 1000);
        // Inflate the layout for this fragment
        return rootView;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
//        mMap.setMyLocationEnabled(true);
        webService = new WebService();
        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(getActivity());
        webService.Login("8da57fac33", String.valueOf(1471653000), String.valueOf(24.8419), String.valueOf(67.0338),requestQueue);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                JSONObject response = webService.getLoginReqResponse();

                Log.d("Responsereq", "----" + response);
                if (response != null && response != null) {
                    if (response.has("dropoffLocations")) {

                        try {
                            String val = response.getString("dropoffLocations");

                            val = val.replace("[","").replace("]","");
                            val = val.replaceAll("\"","");
                            Log.d("val","----"+val);
                            GeoHashUtils geoHashUtils = new GeoHashUtils();
                            double[] var = geoHashUtils.decode(val);
                            Log.d("var","----"+var.length);
                            mMap.addMarker(new MarkerOptions().position(new LatLng(var[0],var[1])));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    } else {

                    Log.d("JSON--->"," "+response);
//                        GeoHashUtils.decode()
                    }

                } else {


                }

            }

        }, 5000);
        buildGoogleApiClient();
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        List<Address> addresses;
        lm = (LocationManager)getActivity().getSystemService(Context.LOCATION_SERVICE);
        //get the last known latitude longitude from network
        location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        Bundle extras = getActivity().getIntent().getExtras();
        if (location != null) {
            Log.d("---","---l");
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 18f));
            address = getCompleteAddressString(location.getLatitude(),location.getLongitude());
            Log.d("---",address);
            mMap.addMarker(new MarkerOptions().position(new LatLng(location.getLatitude(),location.getLongitude())));
        } else {
            Log.d("---","--k");

            mMap.animateCamera(CameraUpdateFactory.zoomTo(13f));
//                address = getCompleteAddressString(latitude, longitude);
//                Log.d("Address----", address);
        }
        //create an instance of geocoder


//        geo = new Geocoder(getActivity(), Locale.getDefault());
//        try
//        {
//            addresses = geo.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
//            if(addresses.get(0).getPostalCode() != null)
//            {
//               address = getCompleteAddressString(location.getLatitude(), location.getLongitude());
//            }
//        }
//        catch (Exception e)
//        {
//
//        }
//        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
//                mGoogleApiClient);
//        Log.d("---Location","---"+mLastLocation);
//        if (mLastLocation != null) {
//            lat = mLastLocation.getLatitude();
//            lng = mLastLocation.getLongitude();
//
//            LatLng loc = new LatLng(lat, lng);
//            mMap.addMarker(new MarkerOptions().position(loc).title("New Marker"));
//            mMap.moveCamera(CameraUpdateFactory.newLatLng(loc));
//        }
//        originMarkers.add(mMap.addMarker(new MarkerOptions()
//                .title("Đại học Khoa học tự nhiên")
//                .position(hcmus)));
//        getLocation();
////        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
////            // TODO: Consider calling
////            //    ActivityCompat#requestPermissions
////            // here to request the missing permissions, and then overriding
////            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
////            //                                          int[] grantResults)
////            // to handle the case where the user grants the permission. See the documentation
////            // for ActivityCompat#requestPermissions for more details.
////            return;
////        }
//        mMap.setMyLocationEnabled(true);
    }

    public void getLocation(){
        gpsTracker = new GPSTracker(getActivity());
        // check if GPS enabled
        if(gpsTracker.canGetLocation()) {
            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();
            Log.d("---", "--" + longitude + "---" + latitude);
            Bundle extras = getActivity().getIntent().getExtras();
            if (extras != null) {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(extras.getDouble("lat"), extras.getDouble("long")), 18f));
            } else {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 13.0f));
//                address = getCompleteAddressString(latitude, longitude);
//                Log.d("Address----", address);
            }

        }

    }

    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
//                Address returnedAddress;
                StringBuilder strReturnedAddress = new StringBuilder("");

//                for (int i = 0; i < returnedAddress.getMaxAddressLineIndex(); i++) {
////                    adress = addresses.get(0);
//
                    strAdd = returnedAddress.getAddressLine(0) + ", " + returnedAddress.getPremises() + ", " + returnedAddress.getLocality() + ", " + returnedAddress.getAdminArea() + ", " + returnedAddress.getCountryName();
//
                    Log.d("---Address---",strAdd);
//                    strReturnedAddress.append(returnedAddress.getAddressLine(0));

//                }
                strAdd = strAdd.replace("null", "");
                Log.d("---Add---",strAdd);
//                strAdd = returnedAddress.toString();
                Log.w("My Current loction", "" + strReturnedAddress.toString());
            } else {
                Log.w("My Current loction", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.w("My Current loction", "Canont get Address!");
        }
        return strAdd;
    }

    private void sendRequest() {
        String origin = address;
        String destination = "Hassan Square Karachi";
        if (origin.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter origin address!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (destination.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter destination address!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            new DirectionFinder(this, origin, destination).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQUEST_CHECK_SETTINGS) {

        if (resultCode == getActivity().RESULT_OK) {

            Log.d("---","---"+resultCode);
            Toast.makeText(getActivity(), "GPS Enabled !", Toast.LENGTH_LONG).show();
        } else {
            Log.d("---","---"+resultCode);
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);
            builder.setAlwaysShow(true);
            PendingResult result =
                    LocationServices.SettingsApi.checkLocationSettings(
                            mGoogleApiClient,
                            builder.build()
                    );

            result.setResultCallback(this);
            Toast.makeText(getActivity(), "Please Enable GPS !", Toast.LENGTH_LONG).show();
        }

    }
}

    @Override
    public void onResult(@NonNull Result result) {

        final Status status = result.getStatus();
        switch (status.getStatusCode()) {
            case LocationSettingsStatusCodes.SUCCESS:

                // NO need to show the dialog;

                break;

            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                //  Location settings are not satisfied. Show the user a dialog

                try {
                    // Show the dialog by calling startResolutionForResult(), and check the result
                    // in onActivityResult().

                    status.startResolutionForResult(getActivity(), REQUEST_CHECK_SETTINGS);

                } catch (IntentSender.SendIntentException e) {

                    //failed to show
                }
                break;

            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                // Location settings are unavailable so not possible to show any dialog now
                break;
        }
    }
@Override
public void onDestroyView()
{
    try{
        SupportMapFragment fragment = ((SupportMapFragment) getFragmentManager().findFragmentById(R.id.map));
        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
        ft.remove(fragment);
        ft.commit();
    }catch(Exception e){
    }
    super.onDestroyView();
}


}
