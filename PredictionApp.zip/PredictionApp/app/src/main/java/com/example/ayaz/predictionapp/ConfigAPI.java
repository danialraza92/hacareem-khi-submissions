package com.example.ayaz.predictionapp;

/**
 * Created by aali on 4/16/2017.
 */

public class ConfigAPI {

    public static final String loginURL= "http://192.168.8.104:3080/bookingDropoff?user_id=8da57fac33&pickup_time=1447102400&pickup_lat=24.8419&pickup_long=67.0349";
    public static final String checkInURL= "http://139.162.56.85:8181/Checkin";
    public static final String customerURL= "http://139.162.56.85:8181/Customer";
    public static final String logoutURL= "http://139.162.56.85:8181/Logout";
    public static final String checkoutURL= "http://139.162.56.85:8181/Checkout";
    public static int id;

}
